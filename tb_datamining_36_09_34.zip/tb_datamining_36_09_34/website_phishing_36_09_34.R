setwd("C:/Users/User/Documents/KUL/tb_datamining_36_09_34")
getwd()


library(caret)
library(doMC)
install.packages("randomForest")

registerDoMC(4)


data <- read.csv('website_phishing.csv', header = F, colClasses = "factor")


names <- c("has_ip", "long_url", "short_service", "has_at", "double_slash_redirect",
           "pref_suf", "has_sub_domain", "ssl_state", "long_domain", "favicon", "port",
           "https_token", "req_url", "url_of_anchor", "tag_links", "SFH", 
           "submit_to_email", "abnormal_url", "redirect", "mouseover", "right_click",
           "popup", "iframe", "domain_Age", "dns_record", "traffic", "page_rank",
           "google_index", "links_to_page", "stats_report", "target") 

names(data) <- names

set.seed(1234)

train_in <- createDataPartition(y = data$target, p = 0.75, list = FALSE)
training <- data[train_in,]
testing <- data[-train_in,]

fitControl = trainControl(method = "repeatedcv", repeats = 5, number = 5,
                          verboseIter = T)
rf.fit <- train(target ~ .,  data = training, method = "rf",
                importance = T, trControl = fitControl, tuneLength = 5)

rf.predict <- predict(rf.fit, testing[,-31])

confusionMatrix(rf.predict, testing$target)

plot(varImp(rf.fit))
